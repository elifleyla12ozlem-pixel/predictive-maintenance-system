Add your actual project screenshots to this folder.
Suggested images:
- app_home.png
- low_risk_prediction.png
- high_risk_prediction.png
- model_evaluation.png
